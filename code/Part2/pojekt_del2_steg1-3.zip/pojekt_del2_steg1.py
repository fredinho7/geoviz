import viz

map_image_file = 'map.png'

def load_and_create_map(filename):
	# load texture image
	texture = viz.add(filename)
	
	# create on-the-fly geometry
	viz.startLayer(viz.POLYGON)
	viz.texCoord(0,0)
	viz.vertex(-1,0,-1)
	
	viz.texCoord(1,0)
	viz.vertex( 1,0,-1)
	
	viz.texCoord(1,1)
	viz.vertex( 1,0, 1)
	
	viz.texCoord(0,1)
	viz.vertex(-1,0, 1)
	
	map_geometry = viz.endLayer()
	map_geometry.texture(texture)

# load & create texture geometry
load_and_create_map(map_image_file)

# position camera so as to see central part of the scene
viz.MainView.setPosition(0,3,-3)
viz.MainView.lookAt([0,0,0])

#start simulation
viz.go()

